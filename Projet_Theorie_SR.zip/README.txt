Ce fichier décrit en premier lieu comment installer ce projet puis comment l'utiliser

>>>>>>>>>> INSTALLATION <<<<<<<<<<

Tout d'abord décompresser le fichier dans le dossier voulu

Ensuite il faut mettre à jour la variable d'environnement GOPATH, pour ce faire entrer dans un terminal :

	export GOPATH=[AdresseFichierGo]

où [AdresseFichierGo] correspond au chemin absolu du fichier contenant le projet (ATTENTION : ne pas mettre les crochet [] ) 
Ce fichier doit avoir une architecture similaire à celle-ci :

[AdresseFichierGo]
	│
	├── bin
	├── src
	│   ├── projet_Client
	│   │		└── client.go
	│   └── projet_Serveur
	│		├── collecteur.go
	│		├── repartiteur.go
	│		├── serveur.go
	│		└── travailleur.go
	├── bin
	│   ├── projet_Client
	│   └── projet_Serveur
	└── README.txt

EXAMPLE : export GOPATH=/mnt/Théorie_SR/MonProjetGo


	>>>>> INSTALLATION DU SERVEUR <<<<<
	
	Pour installer le serveur il faut tout d'abord configurer sur quel port voulez-cous qu'il écoute. 
	Pour ce faire changer 	